# kiwizen 
### Funny and useful codes.
---
## alg
1. kiwizen.alg.IntersectionOfSpaceLines  
Calculate the intersection point of 2 n-dimension lines    
---
    The algorithm to calculate 2 n-dimension lines is shown below:  
![How to calculate the insection point ?](https://github.com/xiaodaxia-2008/Kiwi/blob/master/resources/imgs/InsectionOf2SpaceLines.jpg){:height="100" width="100"}
## plt
2. kiwizen.plt.arrow3d  
Draw an arrow in matplot.pyplot