# kiwizen 
### Funny and useful codes.
---
## alg
1. kiwizen.alg.IntersectionOfSpaceLines  
Calculate the intersection point of 2 n-dimension lines    

## plt
2. kiwizen.plt.arrow3d  
Draw an arrow in matplot.pyplot

